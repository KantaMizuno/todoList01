//
//  ToDoListItem+CoreDataClass.swift
//  CoreDataExample
//
//  Created by iOSDev on 2021/07/27.
//
//

import Foundation
import CoreData

@objc(ToDoListItem)
public class ToDoListItem: NSManagedObject {

}
